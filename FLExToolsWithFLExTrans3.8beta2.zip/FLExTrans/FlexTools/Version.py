#
#   The version name and number to display in the title bar of the 
#   FlexTools window.
#

FTName = "FLExTools"
FTVersion = "2.2.1"

Name = "FLExTrans"

Version = "3.8 Beta 2"

Title = f"{FTName} {FTVersion} ({Name} {Version})"
