#
#   A shell module to launch FlexTools
#

import flextoolslib

from Version import Title
from FLExTransMenu import customMenu

flextoolslib.main(Title, customMenu)
