Instructions for setting up the 2 Irregular Form examples:
----------------------------------------------------------
1. Restore the German and Swedish FLEx projects
2. Go to the WorkProjects subfolder
3. Copy the German-Swedish folder and Paste it where it is. You should see a new folder called German-Swedish - Copy
4. Rename this folder to Swedish-German-Irregular-Form.
3. Copy FlexTrans.config from the Doc\Irregular-Form folder to the WorkProjects\Swedish-German-Irregular-Form\Config folder
5. Copy transfer_rules.t1x from the Doc\Irregular-Form folder to the WorkProjects\Swedish-German-Irregular-Form folder
6. Start FLExTools (from the WorkProjects\Swedish-German-Irregular-Form folder)
7. Click the Database button and choose 'Swedish-FLExTrans-Irregular-Form' as the source database.