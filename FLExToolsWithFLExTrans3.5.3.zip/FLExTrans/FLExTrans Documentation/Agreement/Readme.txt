Instructions for setting up the Agreement example:
--------------------------------------------------
1. Restore the German and Swedish FLEx projects
2. Go to the WorkProjects subfolder
3. Copy the German-Swedish folder and Paste it where it is. You should see a new folder called German-Swedish - Copy
4. Rename this folder to Swedish-German-Agreement.
3. Copy FlexTrans.config from the Doc\Agreement folder to the WorkProjects\Swedish-German-Agreement\Config folder
5. Copy transfer_rules.t1x from the Doc\Agreement folder to the WorkProjects\Swedish-German-Agreement folder
6. Start FLExTools (from the WorkProjects\Swedish-German-Agreement folder)
7. Click the Database button and choose 'Swedish-FLExTrans-Agreement' as the source database.