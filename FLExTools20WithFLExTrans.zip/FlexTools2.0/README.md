FLExTools
=========

FLExTools is a Python scripting utility for SIL FieldWorks Language Explorer ([FLEx])


+ [Wiki]

+ [Latest version]

[FLEx]: http://fieldworks.sil.org/
[Wiki]: https://github.com/cdfarrow/FLExTools/wiki
[Latest version]: https://github.com/cdfarrow/FLExTools/wiki#Setup
