# -*- coding: utf-8 -*-
#
#   ChineseUtilities
#
#   Craig Farrow
#   May 2011
#
#   Support functions for processing Chinese and Pinyin in FLExTools.
#
#

import codecs
import re

import os, sys

import datafiles
from chin_utils import *
from check_pinyin import *
from pinyin import *


# --- Chinese Writing Systems ---


def ChineseWritingSystems(DB, report, Hanzi=False, Tonenum=False, Pinyin=False, Sort=False):
    """
    Returns a list of Language Tags for the requested Chinese writing systems.
    Checks for 'zh-CN' ones first, then 'cmn' ones as an alternative (for
    projects created in FW v6 or earlier).
    """

    def __getWS(languageTag, alternateTag):
        name = DB.WSUIName(languageTag)         # Check WS exists
        if not name:
            name = DB.WSUIName(alternateTag)    # Try alternate
            if not name:
                report.Warning("Writing system not found: %s" % languageTag)
                return None
            return alternateTag
        return languageTag                      # Pass the Tag around

    WSs = []
    if Hanzi:
        WSs.append(__getWS('zh-CN', 'cmn'))

    if Tonenum:
        WSs.append(__getWS('zh-CN-X-PYN', 'cmn--X-PYN'))

    if Pinyin:
        WSs.append(__getWS('zh-CN-X-PY', 'cmn--X-PY'))

    if Sort:
        WSs.append(__getWS('zh-CN-X-ZHSORT', 'cmn--ZHSORT'))
        
    return WSs

            
# --- Chinese Database helper functions and classes ---

class ChineseDB(list):
    def __init__(self, fname=datafiles.DictDB):
        list.__init__(self)
        self.FileName = fname
        self.extend(get_tonenum_dict(fname))
       

class ChineseParser(object):
    def __init__(self, fname=datafiles.DictDB):
        self.segmenter = init_chin_sgmtr([fname])

    def Tonenum(self, hz):
        if hz:
            l = self.segmenter.match_all_ends(hz)
            r = self.segmenter.match_all_starts(hz)
            if l == r:
                try:
                    tonenum = join_segments(self.segmenter, hz, l).strip()
                except KeyError, msg:
                    return u"[Unknown Chinese: %s]" % msg
                return tonenum
            else:
                # Ambiguous
                tonenum1 = join_segments(self.segmenter, hz, l).strip()
                tonenum2 = join_segments(self.segmenter, hz, r).strip()
                return u" | ".join((tonenum1, tonenum2))
        return None

    def CheckTonenum(self, hz, tonenum):
        result = check_pinyin(self.segmenter, hz, tonenum)
        if result:
            err = result[0]             # Trim off the hz in the error string
            match = err.find(": ")
            if match >= 0:
                err = err[match+1:]
            return u"[%s]" % err
        else:
            return None

# --- Tone number to Pinyin

def TonenumberToPinyin(tonenum):
    return tonenum_pinyin(tonenum)
    
# --- Sort String functions and classes ---

def MakeSortString(py, stroke_count, strokes):
    # The Stroke count is represented as letters to make it distinguishable
    # from the tone number. '@' is used for zero.
    ssmap = ['@','A','B','C','D','E','F','G','H','I']
    stroke_count = ssmap[stroke_count / 10] + ssmap[stroke_count % 10]
    # The default ICU sort in Fieldworks ignores punctuation, so
    # we change ':' to '9' so '5' < u-diaresis < 'a'
    # E.g. lu4 < lu94 < luan
    py = py.replace(u':', u'9')
    return "".join([py, stroke_count, strokes])


class SortStringDB(dict):
    
    def __init__(self, fname=datafiles.SortPickle):
        dict.__init__(self)
        self.FileName = fname
        self.__load()

    def __loadFromTextFile(self, fname):
        try:
            f = codecs.open(fname, encoding="utf-8")
        except IOError:
            print "File not found!"
            return

        for line in f.readlines():
            line = line.strip("\n\r")
            parts = line.split("\t")

            mapping = {}
            hz = parts.pop(0)
            if len(parts) % 2 == 0:
                while (parts):
                    py = parts.pop(0)
                    sortKey = parts.pop(0)
                    mapping[py] = sortKey
                self[hz] = mapping

        f.close()

    def __loadFromPickle(self, fname):
        sortData = datafiles.loadSortData(fname)

        for d in sortData.values():
            # d is list of [chr, pinyin, # strokes, order of strokes by type]
            mapping = {}
            for py in d[1]:
                mapping[py] = MakeSortString(py, d[2], d[3])
            self[d[0]] = mapping

            
    def __load(self):
        # This stack-frame code is all that I've found to work for
        # getting the current path from Idle, command-line AND
        # FlexTools (where it is used by a custom-imported module.)
        # (Use of __file__ failed for Idle)
        mypath = os.path.dirname(sys._getframe().f_code.co_filename)
        fname = os.path.join(mypath, self.FileName)

        if fname[-4:] == ".pkl":
            self.__loadFromPickle(fname)
        else:
            self.__loadFromTextFile(fname)

    def Lookup(self, hz, py):
        try:
            sortInfo = self[hz]
        except KeyError:
            if len(hz) > 1:
                return u"[Composed HZ not in DB: %s]" % repr(hz)
            else:
                return u"[HZ not in DB: %s]" % repr(hz)
        try:
            return sortInfo[py]
        except KeyError:
            return u"[PY mismatch]"
        

    def SortString(self, hz, py):
        """
        Return a string that will produce an alphabetical sort for the supplied
        Chinese (hz) and Pinyin with tone numbers (py).
        If there are any errors then the relevant segment will have an
        error message contained in square brackets [].
        """
        if not hz or not py:
            return u""
        
        hzList = get_chars(hz)
        pyList = get_tone_syls(py.lower())
        
        if len(hzList) <> len(pyList):
            return u"[PY different length]"

        return u";".join([self.Lookup(h,p) for h, p in zip(hzList, pyList)])


# --- Testing ---

if __name__ == "__main__":
    if sys.stdout.encoding == None:
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout)

    testSet = [
               (u"路", "lu4"),
               (u"你好", "ni3 hao3"),
               (u"你好吗\N{FULLWIDTH QUESTION MARK}", ""),
               (u"中国", "zhong1 guo4"),
               (u"中国话", "Zhong1guo2hua4"),
               (u"去人民公园",""),
               (u'枣红色',     "zao3hong2se4"),
               (u"录音",      "lu4yin1"),
               (u"录音机",    "lu4yin1"),
               (u"驴",        "lu:2"),
               (u"绿",       "lu:4"),
               (u"乱",       "luan4"),
               (u"耳朵",      "er3duo5"),
               (u"孩子",      "hai2.zi5"),
               (u'\u5ea7\u513f', u'zuor4'),
               (u'\u53ed\u513f\u72d7', u'bar1gou3'),
               (u'\u767d\u773c\u513f\u72fc', u'bai2yanr3lang2'),
               (u'\u5361\u62c9OK', u'ka3la1ou1kei4'),
               (u'左右', u'zuo3you4'),
               (u'左…右…', u'zuo3…you4…'),
               (u'\N{FULLWIDTH SEMICOLON}', u';'),
               (u'连\N{HORIZONTAL ELLIPSIS}也', u'lian2…ye3'),
               ]


    print "--- Testing Chinese Parser and Sort String Generator ---"
    Parser = ChineseParser()
    Sorter = SortStringDB()
    for t in testSet:
        print t[0], repr(t[0])
        print "\tParse:\t", Parser.Tonenum(t[0])
        result = Parser.CheckTonenum(t[0], t[1])
        print "\tCheck:\t", t[1], result if result else "OK"
        ss = Sorter.SortString(t[0], t[1])
        print "\tSort:\t", ss
    
    

