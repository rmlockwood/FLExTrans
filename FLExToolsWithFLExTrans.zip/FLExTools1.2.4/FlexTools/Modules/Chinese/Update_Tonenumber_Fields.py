# -*- coding: utf-8 -*-
#
#   Chinese.Update Tonenumber Fields
#    - A FlexTools Module -
#
#
#   C D Farrow
#   June 2011
#
#   Platforms: Python .NET and IronPython
#

from FTModuleClass import *


#----------------------------------------------------------------
# Documentation for the user:

docs = {FTM_Name       : "Update Chinese Tone Number Fields",
        FTM_Version    : 3,
        FTM_ModifiesDB : True,
        FTM_Synopsis   : "Generate Pinyin with tone numbers from Chinese Hanzi",
        FTM_Help       : r"Doc\Chinese Utilities Help.pdf",
        FTM_Description:
u"""
Populates the Pinyin Numbered (zh-CN-x-pyn) writing system
from the Chinese Hanzi (zh-CN) for:

 - all glosses in the lexicon,

 - forms in a reversal Index based on the 'zh-CN' writing system.

The tone number field is produced as follows:

 - Numerals 1-5 at the end of the Pinyin pronunciation for tones 1-4 plus
 nuetral tone (5), e.g. 'hai2.zi5'

 - u-diaresis is represented with a colon (':') at the end of the syllable
 and before the tone number, e.g. lu:4se4.

Following the Pinyin formatting in 现代汉语词典 (XianDai HanYu CiDian),
the tone number field also has spaces and special
punctuation between certain syllables, e.g. 'lu4//yin1', 'jiao3.zi5'.

Ambiguities in the Pinyin are included as a list of possibilities
separated by a vertical bar '|', e.g. 'zhong1|zhong4'.

If the Pinyin is already present then it is checked
against the Chinese and any inconsistencies reported (e.g. if the Chinese has
been changed without updating the Pinyin.)

Note: So that manual edits are not lost, this Module will not over-write the Pinyin .

See Chinese Utilities Help.pdf for detailed information on configuration and usage.
""" }


from ChineseUtilities import ChineseWritingSystems, ChineseParser

                 
#----------------------------------------------------------------
# The main processing function

def UpdateTonenumberFields(DB, report, modify=False):

    def __CalcNewTonenum(DB, entry, hz, py):
        # Note that DB is passed to each of these local functions otherwise
        # DB is treated as a global and isn't released for garbage collection.
        # That keeps the database locked so FT has to be restarted to use
        # that database again.

        if hz:
            lexeme = DB.LexiconGetLexemeForm(entry)
            if py:
                # If the Pinyin field is populated, NEVER overwrite it.
                # We must not lose any manual editing the user has done.
                msg = Parser.CheckTonenum(hz, py)
                if msg:
                    report.Warning("    %s: (%s, %s) > %s" % (lexeme, hz, py, msg),
                                   DB.BuildGotoURL(entry))
            else:
                tonenum = Parser.Tonenum(hz)
                if "[" in tonenum:
                    report.Warning("    %s: %s > %s" % (lexeme, hz, tonenum),
                                   DB.BuildGotoURL(entry))
                    return None
                if modify:
                    report.Info("    %s - Updating: %s > %s" % (lexeme, hz, tonenum),
                                DB.BuildGotoURL(entry))
                    return tonenum
                else:
                    report.Info("    %s - Needs updating: %s > %s" % (lexeme, hz, tonenum),
                                DB.BuildGotoURL(entry))
        return None

    def __WriteSenseTonenum(DB, entry, sense):
        hz = DB.LexiconGetSenseGloss(sense, ChineseWS)
        py = DB.LexiconGetSenseGloss(sense, ChineseTonenumWS)

        newtonenum = __CalcNewTonenum(DB, entry, hz, py)
        if newtonenum is not None:
            DB.LexiconSetSenseGloss(sense, newtonenum, ChineseTonenumWS)
                
        # Subentries
        for se in sense.SensesOS:
            __WriteSenseTonenum(DB, entry, se)

    def __WriteReversalTonenum(DB, e):
        hz = DB.ReversalGetForm(e, ChineseWS)
        py = DB.ReversalGetForm(e, ChineseTonenumWS)

        newtonenum = __CalcNewTonenum(DB, e, hz, py)
        if newtonenum is not None:
            DB.ReversalSetForm(e, newtonenum, ChineseTonenumWS)
                
        # Subentries (Changed from OC to OS in FW8)
        try:
            subentries = e.SubentriesOC
        except AttributeError:
            subentries = e.SubentriesOS
            
        for se in subentries:
            __WriteReversalTonenum(DB, se)


    # Find the Chinese writing systems

    ChineseWS,\
    ChineseTonenumWS = ChineseWritingSystems(DB, report, Hanzi=True, Tonenum=True)

    if not ChineseWS or not ChineseTonenumWS:
        report.Error("Please read the instructions and configure the necessary writing systems")
        return
    else:
        report.Info("Using these writing systems:")
        report.Info("    Hanzi: %s" % DB.WSUIName(ChineseWS))
        report.Info("    Tone number Pinyin: %s" % DB.WSUIName(ChineseTonenumWS))

    Parser = ChineseParser()
    
    # Lexicon Glosses

    report.Info("Updating tone number Pinyin for all lexical entries")
    report.ProgressStart(DB.LexiconNumberOfEntries())

    for entryNumber, entry in enumerate(DB.LexiconAllEntries()):
        report.ProgressUpdate(entryNumber)
        lexeme = DB.LexiconGetLexemeForm(entry)
        for sense in entry.SensesOS:
            __WriteSenseTonenum(DB, entry, sense)

    # Reversal Index
    
    entries = DB.ReversalEntries(ChineseWS)
    if entries:
        report.ProgressStart(len(list(entries)))
        report.Info("Updating tone number Pinyin for '%s' reversal index"
                    % DB.WSUIName(ChineseWS))
        for entryNumber, entry in enumerate(entries):
            report.ProgressUpdate(entryNumber)
            __WriteReversalTonenum(DB, entry)
    
#----------------------------------------------------------------

FlexToolsModule = FlexToolsModuleClass(runFunction = UpdateTonenumberFields,
                                       docs = docs)
            

#----------------------------------------------------------------
if __name__ == '__main__':
    FlexToolsModule.Help()
