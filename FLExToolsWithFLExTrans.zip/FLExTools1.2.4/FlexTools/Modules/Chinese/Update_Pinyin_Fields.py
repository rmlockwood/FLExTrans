# -*- coding: utf-8 -*-
#
#   Chinese.Update Pinyin Fields
#    - A FlexTools Module -
#
#
#   C D Farrow
#   June 2011
#
#   Platforms: Python .NET and IronPython
#

from FTModuleClass import *


#----------------------------------------------------------------
# Documentation for the user:

docs = {FTM_Name       : "Update Chinese Pinyin Fields",
        FTM_Version    : 3,
        FTM_ModifiesDB : True,
        FTM_Synopsis   : "Generate Pinyin with tone diacritics from the tone numbers",
        FTM_Help       : r"Doc\Chinese Utilities Help.pdf",
        FTM_Description:
u"""
Populates the Pinyin (zh-CN-x-py) writing system
from the Pinyin Numbered (zh-CN-x-pyn) field for:

 - all glosses in the lexicon,

 - forms in a Reversal Index based on the 'zh-CN' writing system.

If the tone number has any unresolved ambiguities then the Pinyin field is
cleared, otherwise the Pinyin field is always overwritten (when database
changes are enabled.)

See Chinese Utilities Help.pdf for detailed information on configuration and usage.
""" }


import unicodedata
from ChineseUtilities import ChineseWritingSystems, TonenumberToPinyin

                 
#----------------------------------------------------------------
# The main processing function

def UpdatePinyinFields(DB, report, modify=False):

    def __CalcNewPinyin(DB, entry, tonenum, pinyin):
        # Note that DB is passed to each of these local functions otherwise
        # DB is treated as a global and isn't released for garbage collection.
        # That keeps the database locked so FT has to be restarted to use
        # that database again.

        if tonenum:
            lexeme = DB.LexiconGetLexemeForm(entry)
            if '|' in tonenum or '[' in tonenum: 
                report.Warning("    %s - Ambiguous tone number: %s" % (lexeme, tonenum),
                               DB.BuildGotoURL(entry))
                if not pinyin:
                    return None
                else:
                    newpinyin = u""     # Clear the Pinyin field
            else:
                newpinyin = TonenumberToPinyin(tonenum)
            
            if unicodedata.normalize('NFD', newpinyin) <> pinyin:
                if modify:
                    report.Info("    %s - Updating %s > %s" % (lexeme, tonenum, newpinyin))
                    return newpinyin
                else:
                    report.Info("    %s - Needs updating: %s > %s" % (lexeme, tonenum, newpinyin))
        return None

    def __WriteSensePinyin(DB, entry, sense):
        tonenum = DB.LexiconGetSenseGloss(sense, ChineseTonenumWS)
        pinyin  = DB.LexiconGetSenseGloss(sense, ChinesePinyinWS)

        newpinyin = __CalcNewPinyin(DB, entry, tonenum, pinyin)
        if newpinyin is not None:
            DB.LexiconSetSenseGloss(sense, newpinyin, ChinesePinyinWS)

        # Subentries
        for se in sense.SensesOS:
            __WriteSensePinyin(DB, entry, se)

    def __WriteReversalPinyin(DB, e):
        tonenum = DB.ReversalGetForm(e, ChineseTonenumWS)
        pinyin  = DB.ReversalGetForm(e, ChinesePinyinWS)

        newpinyin = __CalcNewPinyin(DB, e, tonenum, pinyin)
        if newpinyin is not None:
            DB.ReversalSetForm(e, newpinyin, ChinesePinyinWS)

        # Subentries (Changed from OC to OS in FW8)
        try:
            subentries = e.SubentriesOC
        except AttributeError:
            subentries = e.SubentriesOS
            
        for se in subentries:
            __WriteReversalPinyin(DB, se)


    # Find the Chinese writing systems

    ChineseWS,\
    ChineseTonenumWS,\
    ChinesePinyinWS = ChineseWritingSystems(DB, report, Hanzi=True, Tonenum=True, Pinyin=True)

    if not ChineseTonenumWS or not ChinesePinyinWS:
        report.Error("Please read the instructions and configure the necessary writing systems")
        return
    else:
        report.Info("Using these writing systems:")
        report.Info("    Tone number Pinyin: %s" % DB.WSUIName(ChineseTonenumWS))
        report.Info("    Chinese Pinyin field: %s" % DB.WSUIName(ChinesePinyinWS))
   
    # Lexicon Glosses

    report.Info("Updating Pinyin for all lexical entries")
    report.ProgressStart(DB.LexiconNumberOfEntries())

    for entryNumber, entry in enumerate(DB.LexiconAllEntries()):
        report.ProgressUpdate(entryNumber)
        lexeme = DB.LexiconGetLexemeForm(entry)
        for sense in entry.SensesOS:
            __WriteSensePinyin(DB, entry, sense)

    # Reversal Index

    if ChineseWS:
        entries = DB.ReversalEntries(ChineseWS)
        if entries:
            report.ProgressStart(len(list(entries)))
            report.Info("Updating Pinyin for '%s' reversal index"
                        % DB.WSUIName(ChineseWS))
            for entryNumber, entry in enumerate(entries):
                report.ProgressUpdate(entryNumber)
                __WriteReversalPinyin(DB, entry)


#----------------------------------------------------------------

FlexToolsModule = FlexToolsModuleClass(runFunction = UpdatePinyinFields,
                                       docs = docs)
            

#----------------------------------------------------------------
if __name__ == '__main__':
    FlexToolsModule.Help()
