
This directory contains all FlexTools Modules that are available.
New modules (.py files) can be added to this directory or subdirectories.
They must define FlexToolsModule as illustrated in the Examples directory.

It is suggested that organisations/entities or individual authors create 
a subdirectory for their Modules. These can be distributed as a zipped 
folder and simply unzipped into the Modules directory by end-users.


