#!/bin/sh
sudo chmod 777 /media/flextrans-project/do_make.sh
sudo chmod 777 /media/flextrans-project/live-rule-tester/do_make.sh
sudo crontab /media/flextrans-project/crontab.txt
