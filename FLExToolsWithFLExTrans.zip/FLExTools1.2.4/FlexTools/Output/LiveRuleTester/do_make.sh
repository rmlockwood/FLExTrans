#!/bin/sh
cd /media/flextrans-project/LiveRuleTester
make
