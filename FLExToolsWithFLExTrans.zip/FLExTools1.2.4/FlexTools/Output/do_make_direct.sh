#!/bin/sh
cd Output
make 2>err_out
