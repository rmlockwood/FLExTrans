#!/bin/sh
cd /media/flextrans-project
make
