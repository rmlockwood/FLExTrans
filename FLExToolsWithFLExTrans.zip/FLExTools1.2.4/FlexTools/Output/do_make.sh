#!/bin/sh
cd /media/flextrans-project
make 2>err_out
