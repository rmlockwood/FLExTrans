
import sys
import os
customFWPath = os.path.expandvars("$ProgramFiles\SIL\Fieldworks 7")
sys.path.append(customFWPath)
#print "Using custom FW path:", customFWPath
