#
#   Version.py
#
#   Current version number for FLExTools
#

number = "2.1.2"

# Minimum and maximum supported versions of Fieldworks
# (Later versions should work if the LCM interface hasn't changed.)
MinFWVersion = "9.0.4"
MaxFWVersion = "9.1.12"
