Instructions for setting up the 2 Irregular Form examples example:
--------------------------------------------------
1. Restore the German and Swedish FLEx projects
2. Make backup copies of FlexTrans.config and transfer_rules.t1x
3. Copy FlexTrans.config from this folder to the FlexTools folder
4. Copy transfer_rules.t1x to the FlexTools\Output folder
5. Start FLExTools
6. Click the Database button and choose 'Swedish-FLExTrans-Agreement' as the source database.