#
#   Version.py
#
#   Current version number for FLExTools
#

number = "1.2.4"

# Minimum and maximum supported versions of Fieldworks
# (Later versions should work if the FDO interface hasn't changed.)
MinFWVersion = "7.2.0"
MaxFWVersion = "8.2.2"

