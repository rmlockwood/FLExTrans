#
#   Settings GUI
#   Lærke Roager Christensen
#   3/28/22
#
#   Version 3.5.4 - 7/13/22 - Ron Lockwood
#    Give error if fail to open target DB.
#
#   Version 3.5.3 - 6/24/22 - Ron Lockwood
#    Call CloseProject() for FlexTools2.1.1 fixes #159
#
#   Version 3.5.2 - 6/21/22 - Ron Lockwood
#    Fixes for #141 and #144. Alphabetize source text list. Correctly load
#    and save source complex types. Also change double loop code for multiple
#    select settings to use x in y instead of the outer loop. This is easier to
#    understand and is maybe more efficient.
#
#   Version 3.5.1 - 6/13/22 - Ron Lockwood
#    import change for flexlibs for FlexTools2.1
#
#   To make it easier to change the configfile
#

import os
import sys


from FTModuleClass import FlexToolsModuleClass
from FTModuleClass import *
from SIL.LCModel import *
from SIL.LCModel.Core.KernelInterfaces import ITsString, ITsStrBldr

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QFontDialog, QMessageBox, QMainWindow, QApplication, QFileDialog

from Settings import Ui_MainWindow
from ComboBox import CheckableComboBox
from flexlibs import FLExProject, AllProjectNames

import Utils
import ReadConfig
from FTPaths import CONFIG_PATH

# ----------------------------------------------------------------
# Documentation that the user sees:

docs = {FTM_Name: "Settings Tool",
        FTM_Version: "3.5.4",
        FTM_ModifiesDB: False,
        FTM_Synopsis: "Change FLExTrans settings.",
        FTM_Help: "",
        FTM_Description:
            """
Change FLExTrans settings.            
            """}

# ----------------------------------------------------------------
# The main processing function
class Main(QMainWindow):

    def __init__(self, configMap, report, targetDB, DB):
        QMainWindow.__init__(self)
        # RL code review 23Jun22: I think it is good practice to put assigning of parameter values at the top of the method
        self.report = report
        self.configMap = configMap
        self.targetDB = targetDB
        self.DB = DB

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        
        # CONFIG_PATH holds the full path to the flextools.ini file which should be in the WorkProjects/xyz/Config folder. That's where we find FLExTools.config
        # Get the parent folder of flextools.ini, i.e. Config and add FLExTools.config
        myPath = os.path.join(os.path.dirname(CONFIG_PATH), ReadConfig.CONFIG_FILE)
        
        self.config = myPath

        #Buttons
        self.ui.apply_button.clicked.connect(self.save)
        self.ui.a_text_button.clicked.connect(self.open_a_text)
        self.ui.ana_file_button.clicked.connect(self.open_ana_file)
        self.ui.syn_file_button.clicked.connect(self.open_syn_file)
        self.ui.transfer_result_file_button.clicked.connect(self.open_tranfer_result)
        self.ui.bi_dictionary_uotfile_button.clicked.connect(self.open_bi_dic_file)
        self.ui.bi_dictionary_replacefile_button.clicked.connect(self.open_bi_dic_replacefile)
        self.ui.target_affix_list_button.clicked.connect(self.open_affix_list)
        self.ui.a_tretran_outfile_button.clicked.connect(self.open_a_treetran)
        self.ui.tretran_insert_words_button.clicked.connect(self.open_insert_words)
        self.ui.transfer_rules_button.clicked.connect(self.open_transfer_rules)
        self.ui.testbed_button.clicked.connect(self.open_testbed)
        self.ui.testbed_result_button.clicked.connect(self.open_testbed_result)
        self.ui.reset_button.clicked.connect(self.reset)

        self.init_load()

    # RL code review 23Jun22: Could connect() calls above call browse() directly?
    def open_a_text(self):
        self.browse(self.ui.output_filename, "(*.*)")

    def open_ana_file(self):
        self.browse(self.ui.output_ANA_filename, "(*.*)")

    def open_syn_file(self):
        self.browse(self.ui.output_syn_filename, "(*.*)")

    def open_tranfer_result(self):
        self.browse(self.ui.transfer_result_filename, "(*.*)")

    def open_bi_dic_file(self):
        self.browse(self.ui.bilingual_dictionary_output_filename, "(*.*)")

    def open_bi_dic_replacefile(self):
        self.browse(self.ui.bilingual_dictionary_repalce_file_2, "(*.*)")

    def open_affix_list(self):
        self.browse(self.ui.taget_affix_gloss_list_filename, "(*.*)")

    def open_a_treetran(self):
        self.browse(self.ui.a_treetran_output_filename, "(*.*)")

    def open_insert_words(self):
        self.browse(self.ui.treetran_insert_words_file_2, "(*.*)")

    def open_transfer_rules(self):
        self.browse(self.ui.transfer_rules_filename, "(*.*)")

    def open_testbed(self):
        self.browse(self.ui.testbed_filename, "(*.*)")

    def open_testbed_result(self):
        self.browse(self.ui.testbed_result_filename, "(*.*)")

    def browse(self, name, end):
        filename, _ = QFileDialog.getOpenFileName(self, "Open file", "", end)
        if filename:
            name.setText(os.path.relpath(filename).replace(os.sep, '/'))
            name.setToolTip(os.path.abspath(filename).replace(os.sep, '/'))

    def read(self, key):
        return ReadConfig.getConfigVal(self.configMap, key, self.report)

    def init_load(self):
        
        # RL code review 23Jun22: I prefer a space after #
        # Clear all
        self.ui.chose_sourc_text.clear()
        self.ui.chose_entry_link.clear()
        self.ui.chose_sense_number.clear()
        self.ui.chose_target_project.clear()
        self.ui.chose_source_compex_types.clear()
        self.ui.chose_infelction_first_element.clear()
        self.ui.chose_infelction_second_element.clear()
        self.ui.chose_target_morpheme_types.clear()
        self.ui.chose_source_morpheme_types.clear()
        self.ui.chose_source_discontiguous_compex.clear()
        self.ui.chose_skipped_source_words.clear()
        self.ui.category_abbreviation_one.clear()
        self.ui.category_abbreviation_one.addItem("...")
        self.ui.category_abbreviation_two.clear()
        self.ui.category_abbreviation_two.addItem("...")

        # load all               # RL code review 23Jun22: I'm also a big proponent of white space to make code more readable.
        # Source Text name
        source_list = []
        for item in self.DB.ObjectsIn(ITextRepository):

            source_list.append(str(item).strip())

        sorted_source_list = sorted(source_list, key=str.casefold)
        
        # RL code review 23Jun22: below is how I might add whitespace, not a must, but it could help other people who are reading the code
        config_source = self.read(ReadConfig.SOURCE_TEXT_NAME)
        
        for i, item_str in enumerate(sorted_source_list):
            
            self.ui.chose_sourc_text.addItem(item_str)
            
            if item_str == config_source:
                
                self.ui.chose_sourc_text.setCurrentIndex(i)
        
        # RL code review 23Jun22: in Python you can also do: 
        # for i, item in enumerate(self.DB.LexiconGetSenseCustomFields()):  - this way you don't have to initialize i or increment i
        # Source Custom field for Entry Link and Sense number
        for i, item in enumerate(self.DB.LexiconGetSenseCustomFields()):

            # Add the element to the comboBox, item[1] is because item is some sort of tuple value
            self.ui.chose_entry_link.addItem(str(item[1]))            # RL code review 23Jun22: why item[1]? maybe explain
            self.ui.chose_sense_number.addItem(str(item[1]))          # RL code review 23Jun22: why convert to a str, but not in the next line?

            # Check the currently selected value
            if item[1] == self.read(ReadConfig.SOURCE_CUSTOM_FIELD_ENTRY):
                self.ui.chose_entry_link.setCurrentIndex(i)

            if item[1] == self.read(ReadConfig.SOURCE_CUSTOM_FIELD_SENSE_NUM):
                self.ui.chose_sense_number.setCurrentIndex(i)

        # Target Projects
        #TODO Make this disable the other stuff that uses target??
        for i, item in enumerate(AllProjectNames()):
            self.ui.chose_target_project.addItem(item)
            if item == self.read('TargetProject'):
                self.ui.chose_target_project.setCurrentIndex(i)
        
        # RL code review 23Jun22: for easier maintenance of the code, it would be better have something like x = self.read('AnalyzedTextOutputFile')
        # and then use x twice in the next two lines. This way if the 'AnalyzedTextOutputFile' changes, you only have to change it once.
        # Also, it's nice if we could use constants for all these strings, in fact you will find most of them in ReadConfig.py so you could use ReadConfig.ANALYZED_TEXT_FILE, etc.
        # Analyzed Text file
        analyzedText = self.read(ReadConfig.ANALYZED_TEXT_FILE)
        self.ui.output_filename.setText(os.path.relpath(analyzedText).replace(os.sep, '/'))
        self.ui.output_filename.setToolTip(os.path.abspath(analyzedText).replace(os.sep, '/'))

        # Output ANA file
        ANAFile = self.read(ReadConfig.TARGET_ANA_FILE)
        self.ui.output_ANA_filename.setText(os.path.relpath(ANAFile).replace(os.sep, '/'))
        self.ui.output_ANA_filename.setToolTip(os.path.abspath(ANAFile).replace(os.sep, '/'))

        # Output Synthesis file
        synFile = self.read(ReadConfig.TARGET_SYNTHESIS_FILE)
        self.ui.output_syn_filename.setText(os.path.relpath(synFile).replace(os.sep, '/'))
        self.ui.output_syn_filename.setToolTip(os.path.abspath(synFile).replace(os.sep, '/'))

        # Transfer result file
        transferFile = self.read(ReadConfig.TRANSFER_RESULTS_FILE)
        self.ui.transfer_result_filename.setText(os.path.relpath(transferFile).replace(os.sep, '/'))
        self.ui.transfer_result_filename.setToolTip(os.path.abspath(transferFile).replace(os.sep, '/'))

        # RL code review 23Jun22: It would be nice to explain in a comment which setting is being loaded as well as
        # what you have here saying the data comes from the Complex Form Types list
        # From the Complex Form Types list
        array = []
        for item in self.DB.lp.LexDbOA.ComplexEntryTypesOA.PossibilitiesOS:

            array.append(str(item))

        self.ui.chose_source_compex_types.addItems(array)
        
        # RL code review 23Jun22: Again for maintenance it would be better to have something like settingStr = self.read('SourceComplexTypes') then use settingStr twice
        # Source Complex Types
        complexType = self.read(ReadConfig.SOURCE_COMPLEX_TYPES)
        if complexType:

            for test in complexType:

                if test in array:
                    self.ui.chose_source_compex_types.check(test)

        # Bilingual Dictionary output file
        biDictFile = self.read(ReadConfig.BILINGUAL_DICTIONARY_FILE)
        self.ui.bilingual_dictionary_output_filename.setText(os.path.relpath(biDictFile).replace(os.sep, '/'))
        self.ui.bilingual_dictionary_output_filename.setToolTip(os.path.abspath(biDictFile).replace(os.sep, '/'))

        # Bilingual Dictionary replace file
        biDictReplaceFile = self.read(ReadConfig.BILINGUAL_DICT_REPLACEMENT_FILE)
        self.ui.bilingual_dictionary_repalce_file_2.setText(os.path.relpath(biDictReplaceFile).replace(os.sep, '/'))
        self.ui.bilingual_dictionary_repalce_file_2.setToolTip(os.path.abspath(biDictReplaceFile).replace(os.sep, '/'))

        # Affix Gloss list file
        affixGlossFile = self.read(ReadConfig.TARGET_AFFIX_GLOSS_FILE)
        self.ui.taget_affix_gloss_list_filename.setText(os.path.relpath(affixGlossFile).replace(os.sep, '/'))
        self.ui.taget_affix_gloss_list_filename.setToolTip(os.path.abspath(affixGlossFile).replace(os.sep, '/'))

        #From the Complex Form Types list
        array = []
        for item in self.targetDB.lp.LexDbOA.ComplexEntryTypesOA.PossibilitiesOS:

            array.append(str(item))

        # Forms for inflection
        # Add items to both first and second element
        self.ui.chose_infelction_first_element.addItems(array)
        self.ui.chose_infelction_second_element.addItems(array)

        # Check the elements on first element
        firstElm = self.read(ReadConfig.TARGET_FORMS_INFLECTION_1ST)
        if firstElm:

            for test in firstElm:

                if test in array:
                    self.ui.chose_infelction_first_element.check(test)

        # Check the elements on second element
        secondElm = self.read(ReadConfig.TARGET_FORMS_INFLECTION_2ND)
        if secondElm:

            for test in secondElm:

                if test in array:
                    self.ui.chose_infelction_second_element.check(test)

        # From the Morpheme Types list
        # Target Morpheme Names Counted As Roots
        array = []
        for item in self.targetDB.lp.LexDbOA.MorphTypesOA.PossibilitiesOS:

            # Strip is because morpheme types come with some add-ons that are not necessary for the user in this case
            array.append(str(item).strip("-=~*")) # RL code review 23Jun22: explain the strip()

        self.ui.chose_target_morpheme_types.addItems(array)

        for test in self.read(ReadConfig.TARGET_MORPHNAMES):

            if test in array:

                self.ui.chose_target_morpheme_types.check(test)

        # Source Morpheme Names Counted As Roots
        array = []
        for item in self.DB.lp.LexDbOA.MorphTypesOA.PossibilitiesOS:

            # Strip is because morpheme types come with some add-ons that are not necessary for the user in this case
            array.append(str(item).strip("-=~*"))

        self.ui.chose_source_morpheme_types.addItems(array)

        for test in self.read(ReadConfig.SOURCE_MORPHNAMES):

            if test in array:

                self.ui.chose_source_morpheme_types.check(test)


        # From the Complex Form Types list.
        # Source Discontigous Complex Types
        array = []
        for item in self.DB.lp.LexDbOA.ComplexEntryTypesOA.PossibilitiesOS:

            array.append(str(item))

        self.ui.chose_source_discontiguous_compex.addItems(array)

        disComplexTypes = self.read(ReadConfig.SOURCE_DISCONTIG_TYPES)
        if disComplexTypes:
            for test in disComplexTypes:

                if test in array:

                    self.ui.chose_source_discontiguous_compex.check(test)

        # From the category abbreviation list.
        # Source Discontigous Complex Form Skipped Word Grammatical Categories
        array = []
        for pos in self.DB.lp.AllPartsOfSpeech:

            posAbbrStr = ITsString(pos.Abbreviation.BestAnalysisAlternative).Text
            array.append(posAbbrStr)

        self.ui.chose_skipped_source_words.addItems(array)

        disSkipped = self.read(ReadConfig.SOURCE_DISCONTIG_SKIPPED)
        if disSkipped:
            for test in disSkipped:

                if test in array:

                    self.ui.chose_skipped_source_words.check(test)

        # Analyzed text treeTran output file, if there are any
        analyzedTreeTran = self.read(ReadConfig.ANALYZED_TREETRAN_TEXT_FILE)
        if analyzedTreeTran:
            self.ui.a_treetran_output_filename.setText(os.path.relpath(analyzedTreeTran).replace(os.sep, '/'))
            self.ui.a_treetran_output_filename.setToolTip(os.path.abspath(analyzedTreeTran).replace(os.sep, '/'))

        # TreeTran insert words file, if there are any
        treeTranFile = self.read(ReadConfig.TREETRAN_INSERT_WORDS_FILE)
        if treeTranFile:
            self.ui.treetran_insert_words_file_2.setText(os.path.relpath(treeTranFile).replace(os.sep, '/'))
            self.ui.treetran_insert_words_file_2.setToolTip(os.path.abspath(treeTranFile).replace(os.sep, '/'))

        # Transfer Rules file
        transferRulesFile = self.read(ReadConfig.TRANSFER_RULES_FILE)
        self.ui.transfer_rules_filename.setText(os.path.relpath(transferRulesFile).replace(os.sep, '/'))
        self.ui.transfer_rules_filename.setToolTip(os.path.abspath(transferRulesFile).replace(os.sep, '/'))

        # Testbed File
        testbedFile = self.read(ReadConfig.TESTBED_FILE)
        self.ui.testbed_filename.setText(os.path.relpath(testbedFile).replace(os.sep, '/'))
        self.ui.testbed_filename.setToolTip(os.path.abspath(testbedFile).replace(os.sep, '/'))

        # Testbed Result file
        testbedResultFile = self.read(ReadConfig.TESTBED_RESULTS_FILE)
        self.ui.testbed_result_filename.setText(os.path.relpath(testbedResultFile).replace(os.sep, '/'))
        self.ui.testbed_result_filename.setToolTip(os.path.abspath(testbedResultFile).replace(os.sep, '/'))

        # From the category abbreviation list.
        # Category Abbreviation Substitution List, check if chosen
        catAbbrevList = self.read(ReadConfig.CATEGORY_ABBREV_SUB_LIST)
        for i, pos in enumerate(self.DB.lp.AllPartsOfSpeech):

            posAbbrStr = ITsString(pos.Abbreviation.BestAnalysisAlternative).Text
            self.ui.category_abbreviation_one.addItem(posAbbrStr)

            if catAbbrevList:
                if posAbbrStr == catAbbrevList[0]: # The first one in the config file

                    self.ui.category_abbreviation_one.setCurrentIndex(i)

        for i, pos in enumerate(self.targetDB.lp.AllPartsOfSpeech):

            posAbbrStr = ITsString(pos.Abbreviation.BestAnalysisAlternative).Text
            self.ui.category_abbreviation_two.addItem(posAbbrStr)

            if catAbbrevList:
                if posAbbrStr == catAbbrevList[1]: # The second one in the config file

                    self.ui.category_abbreviation_two.setCurrentIndex(i)

        # Clean Up Unknown target Words
        if self.read(ReadConfig.CLEANUP_UNKNOWN_WORDS) == 'y':

            self.ui.cleanup_yes.setChecked(True)

        # Punctuation
        self.ui.punctuation.setText(self.read(ReadConfig.SENTENCE_PUNCTUATION))
        # Align left as default
        self.ui.punctuation.setAlignment(Qt.AlignLeft)

    def save(self):
        # RL code review 23Jun22: maybe a better variable name
        punctSelected='n'
        if self.ui.cleanup_yes.isChecked():
            punctSelected='y'
        f = open(self.config, "w", encoding='utf-8')
        
        # RL code review 23Jun22: I personally would prefer each line to have f.write(...), but this is ok
        # this is going to hard to maintain since we don't know which setting is connected to which ui element and what kind of data will be coming from that ui element
        # The only solution might be too much work, but somehow have a list with the setting string, the ui element, and a type and then use a loop to put out the appropriate 
        # string based on it's type. In theory it might make it easier to add new settings just at the top and the rest of the code does loops over the master list.
        # Just an idea.
        f.write("SourceTextName="+self.ui.chose_sourc_text.currentText()+"\n"+
                "AnalyzedTextOutputFile="+self.ui.output_filename.text()+"\n"+
                "TargetOutputANAFile="+self.ui.output_ANA_filename.text()+"\n"+
                "TargetOutputSynthesisFile="+self.ui.output_syn_filename.text()+"\n"+
                "TargetTranferResultsFile="+self.ui.transfer_result_filename.text()+"\n"+
                "SourceComplexTypes="+self.optional_mul(self.ui.chose_source_compex_types.currentData())+"\n"+
                "SourceCustomFieldForEntryLink="+self.ui.chose_entry_link.currentText()+"\n"+
                "SourceCustomFieldForSenseNum="+self.ui.chose_sense_number.currentText()+"\n"+
                "TargetAffixGlossListFile="+self.ui.taget_affix_gloss_list_filename.text()+"\n"+
                "BilingualDictOutputFile="+self.ui.bilingual_dictionary_output_filename.text()+"\n"+
                "BilingualDictReplacementFile="+self.ui.bilingual_dictionary_repalce_file_2.text()+"\n"+
                "TargetProject="+self.ui.chose_target_project.currentText()+"\n"+
                "TargetComplexFormsWithInflectionOn1stElement="+self.optional_mul(self.ui.chose_infelction_first_element.currentData())+"\n"+
                "TargetComplexFormsWithInflectionOn2ndElement="+self.optional_mul(self.ui.chose_infelction_second_element.currentData())+"\n"+
                "TargetMorphNamesCountedAsRoots="+self.optional_mul(self.ui.chose_target_morpheme_types.currentData())+"\n"+ #stem,bound stem,root,bound root,phrase
                "SourceMorphNamesCountedAsRoots="+self.optional_mul(self.ui.chose_source_morpheme_types.currentData())+"\n"+#stem,bound stem,root,bound root,phrase
                "SourceDiscontigousComplexTypes="+self.optional_mul(self.ui.chose_source_discontiguous_compex.currentData())+"\n"+
                "SourceDiscontigousComplexFormSkippedWordGrammaticalCategories="+self.optional_mul(self.ui.chose_skipped_source_words.currentData())+"\n"+
                "AnalyzedTextTreeTranOutputFile="+self.ui.a_treetran_output_filename.text()+"\n"+
                "TreeTranInsertWordsFile="+self.ui.treetran_insert_words_file_2.text()+"\n"+
                "TransferRulesFile="+self.ui.transfer_rules_filename.text()+"\n"+
                "TestbedFile="+self.ui.testbed_filename.text()+"\n"+
                "TestbedResultsFile="+self.ui.testbed_result_filename.text()+"\n"+
                "# This property is in the form source_cat,target_cat. Multiple pairs can be defined\n"+
                "CategoryAbbrevSubstitutionList="+self.optional(self.ui.category_abbreviation_one)+","+self.optional(self.ui.category_abbreviation_two)+"\n"+
                "CleanUpUnknownTargetWords="+punctSelected+"\n"+
                "SentencePunctuation="+self.ui.punctuation.text()+"\n")
        f.close()
        msgBox = QMessageBox()
        msgBox.setText("Your file has been successfully saved.")
        msgBox.setWindowTitle("Successful save")
        msgBox.exec()

    def optional(self, string):
        write = ''
        if string.currentText() != '...':
            write = string.currentText()
        return write

    def optional_mul(self, array):
        write = ''
        if array:
            for text in array:
                write += text + ","
        return write

    def reset(self):
        f = open(self.config, "w", encoding='utf-8') # TODO change here when new standard
        f.write("SourceTextName=Text1\n" +
                "AnalyzedTextOutputFile=Output\\source_text.aper\n" +
                "TargetOutputANAFile=Build\\myText.ana\n" +
                "TargetOutputSynthesisFile=Output\\myText.syn\n" +
                "TargetTranferResultsFile=Output\\target_text.aper\n" +
                "SourceComplexTypes=\n" +
                "SourceCustomFieldForEntryLink=Target Equivalent\n" +
                "SourceCustomFieldForSenseNum=Target Sense Number\n" +
                "BilingualDictOutputFile=Output\\bilingual.dix\n" +
                "BilingualDictReplacementFile=replace.dix\n" +
                "TargetProject=Swedish-FLExTrans-Sample\n" +
                "TargetAffixGlossListFile=Build\\target_affix_glosses.txt\n" +
                "TargetComplexFormsWithInflectionOn1stElement=\n" +
                "TargetComplexFormsWithInflectionOn2ndElement=\n" +
                "TargetMorphNamesCountedAsRoots=stem,bound stem,root,bound root,phrase,\n" +
                "SourceMorphNamesCountedAsRoots=stem,bound stem,root,bound root,phrase,\n" +
                "SourceDiscontigousComplexTypes=\n" +
                "SourceDiscontigousComplexFormSkippedWordGrammaticalCategories=\n" +
                "AnalyzedTextTreeTranOutputFile=\n" +
                "TreeTranInsertWordsFile=\n" +
                "TransferRulesFile=transfer_rules.t1x\n" +
                "TestbedFile=testbed.xml\n" +
                "TestbedResultsFile=Output\\testbed_results.xml\n" +
                "# This property is in the form source_cat,target_cat. Multiple pairs can be defined\n" +
                "CategoryAbbrevSubstitutionList=\n" +
                "CleanUpUnknownTargetWords=n\n" +
                "SentencePunctuation=.?;:!\"\'\n")
        f.close()
        self.init_load()



def MainFunction(DB, report, modify=True):
    # Read the configuration file which we assume is in the current directory.

    configMap = ReadConfig.readConfig(report)
    if not configMap:
        report.error('Error reading configuration file.')
        return

    TargetDB = FLExProject()

    try:
        # Open the target database
        targetProj = ReadConfig.getConfigVal(configMap, 'TargetProject', report)
        if not targetProj:
            return
        TargetDB.OpenProject(targetProj, False)
    except:
        report.Error('Failed to open the target database.')
        raise

    # Show the window
    app = QApplication(sys.argv)

    window = Main(configMap, report, TargetDB, DB,) #sourceDB

    window.show()

    app.exec_()
    msgBox = QMessageBox()
    if QMessageBox().question(msgBox, 'Save?', "Do you want to save before you leave?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No) == QMessageBox.Yes:
        window.save()

    TargetDB.CloseProject()

# ----------------------------------------------------------------
# The name 'FlexToolsModule' must be defined like this:
FlexToolsModule = FlexToolsModuleClass(runFunction=MainFunction,
                                       docs=docs)

# ----------------------------------------------------------------
if __name__ == '__main__':
    FlexToolsModule.Help()
