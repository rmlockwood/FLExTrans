Instructions for setting up the 2 Irregular Form examples:
----------------------------------------------------------
1. Restore the German-FLExTrans-Irregular-Form and Swedish-FLExTrans-Irregular-Form FLEx projects by double-clicking on each of the backup files in turn.
2. Go to the WorkProjects subfolder
3. Copy the TemplateProject folder and Paste it where it is. You should see a new folder called TemplateProject - Copy
4. Rename this folder to Swedish-German-Irregular-Form.
3. Copy FlexTrans.config from the FLExTrans Documentation\Irregular-Form folder to the WorkProjects\Swedish-German-Irregular-Form\Config folder (replacing the existing file).
5. Copy transfer_rules.t1x from the FLExTrans Documentation\Irregular-Form folder to the WorkProjects\Swedish-German-Irregular-Form folder (replacing the existing file).
6. Start FLExTools (from the WorkProjects\Swedish-German-Irregular-Form folder)
7. Click the German-FLExTrans-Sample button and choose 'Swedish-FLExTrans-Irregular-Form' as the source database.