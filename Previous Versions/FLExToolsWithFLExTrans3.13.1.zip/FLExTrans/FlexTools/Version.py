#
#   The version name and number to display in the title bar of the 
#   FlexTools window.
#

FTName = "FLExTools"
FTVersion = "2.3.1"

Name = "FLExTrans"

Version = "3.13.1"

Title = f"{FTName} {FTVersion} ({Name} {Version})"
