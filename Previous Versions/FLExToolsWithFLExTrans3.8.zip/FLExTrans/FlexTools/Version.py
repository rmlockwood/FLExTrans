#
#   The version name and number to display in the title bar of the 
#   FlexTools window.
#

Name = "FLExTrans"

Version = "3.8"

Title = f"{Name} {Version}"
