#
#   The version name and number to display in the title bar of the 
#   FlexTools window.
#
#   Version 3.8 - 4/21/23 - Ron Lockwood
#    Bumped FlexTools versions to 2.2.2 and FLExTrans to 3.8 Beta 4
#

FTName = "FLExTools"
FTVersion = "2.2.2"

Name = "FLExTrans"

Version = "3.8"

Title = f"{FTName} {FTVersion} ({Name} {Version})"
