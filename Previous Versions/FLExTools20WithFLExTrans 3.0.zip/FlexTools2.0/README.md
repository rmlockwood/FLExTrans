FLExTools
=========

FLExTools is a Python scripting utility for SIL's [FieldWorks Language Explorer](https://software.sil.org/fieldworks/).


Read all about it on the [wiki](https://github.com/cdfarrow/flextools/wiki/)
