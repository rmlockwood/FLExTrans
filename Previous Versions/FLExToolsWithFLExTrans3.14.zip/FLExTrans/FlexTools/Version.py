#
#   The version name and number to display in the title bar of the 
#   FlexTools window.
#

FTName = "FLExTools"
FTVersion = "2.3.2"

Name = "FLExTrans"

Version = "3.14"
Build = "537"
BuildDate = "Jan 29, 2026"

Title = f"{FTName} {FTVersion} ({Name} {Version})"
