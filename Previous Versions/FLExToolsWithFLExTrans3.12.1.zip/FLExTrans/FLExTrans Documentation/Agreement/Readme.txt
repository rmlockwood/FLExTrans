Instructions for setting up the Agreement example:
--------------------------------------------------
1. Restore the German-FLExTrans-Agreement and Swedish-FLExTrans-Agreement FLEx projects by double-clicking on each of the backup files in turn.
2. Go to the WorkProjects subfolder
3. Copy the TemplateProject folder and Paste it where it is. You should see a new folder called TemplateProject - Copy
4. Rename this folder to Swedish-German-Agreement.
3. Copy FlexTrans.config from the FLExTrans Documentation\Agreement folder to the WorkProjects\Swedish-German-Agreement\Config folder (replacing the existing file).
5. Copy transfer_rules.t1x from the FLExTrans Documentation\Agreement folder to the WorkProjects\Swedish-German-Agreement folder (replacing the existing file).
6. Start FLExTools (from the WorkProjects\Swedish-German-Agreement folder)
7. Click the German-FLExTrans-Sample button and choose 'Swedish-FLExTrans-Agreement' as the source database.