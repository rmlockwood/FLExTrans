#
#   The version name and number to display in the title bar of the 
#   FlexTools window.
#

FTName = "FLExTools"
FTVersion = "2.3.2"

Name = "FLExTrans"

Version = "3.15"
Build = "000"
BuildDate = "Jan 1, 1964"

Title = f"{FTName} {FTVersion} ({Name} {Version})"
